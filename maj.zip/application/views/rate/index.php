<div class="container-fluid">

<!-- <iframe src="https://kursdollar.net/" width="100%" height="500"></iframe> -->
    <div id="div_chart_spot" align="center"></div>
<script src="https://kursdollar.net/widget/widget.js"></script>
<script>
    v_widget_type='chart_spot';
    v_width="100%";
    v_height=300;
    kdcom_chart(v_widget_type,v_width,v_height,'div_chart_spot');
</script>
<div id="div_bi" align="center"></div>
<script src="https://kursdollar.net/widget/widget.js"></script>
<script>
    v_widget_type='kurs_bi';
    v_width="100%";
    v_height=180;
    kd_net_show(v_widget_type,v_width,v_height,'div_bi');
</script>
</div>